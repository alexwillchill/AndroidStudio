package com.example.kotlinvariablestest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        printSongToConsole()
        //var - variable
        //val- constant
        //var declareation var varname : type = value
    }
}