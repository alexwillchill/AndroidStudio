package com.example.kotlinvariablestest

class VariablesText {
}