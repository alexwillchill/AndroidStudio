package com.example.kotlinvariablestest

import android.util.Log


/***************************My Favourite Song*****************************************************/
//This file for my favourite song and the attributes of the song

var Song : String = "Aston Martin Music"
var Artists : String = "Rick Ross, Drake and Chrisette Michele "
var YearReleased : Int = 2010
var Genre: String = "HipHop"
var Duration: Float = 6.47f
var IsExplicit: Boolean = false
var AlphabeticalList: Char = 'A'
var MoneyIMadeFromIt: Double = 0.00



fun printSongToConsole(){
    val ReleaseYear = YearReleased.toString()
    val Durarara = Duration.toString()
    val explicit= IsExplicit.toString()
    val alpha = AlphabeticalList.toString()
    val monetize = MoneyIMadeFromIt.toString()
    Log.d("Name of Song", Song)
    Log.d("Name of Artist", Artists)
    Log.d("Year of Release", ReleaseYear)
    Log.d("Genre", Genre)
    Log.d("Duration", Durarara)
    Log.d("Explicit Content", explicit)
    Log.d("Alphabet Start", alpha)
    Log.d("Money I gained", monetize)
}